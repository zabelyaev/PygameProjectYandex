import pygame
from pygame.sprite import Sprite


class Platform(Sprite):
    def __init__(self, pos, *sprite_groups):
        super().__init__(*sprite_groups)

        self.image = pygame.Surface([100, 10])
        self.image.fill((125, 125, 125))

        self.rect = self.image.get_rect()
        self.rect.x = pos[0]
        self.rect.y = pos[1]
