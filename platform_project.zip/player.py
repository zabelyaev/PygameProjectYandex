import pygame
from pygame.sprite import Sprite


class Player(Sprite):
    def __init__(self, pos, *sprite_groups):
        super().__init__(*sprite_groups)

        self.image = pygame.Surface([20, 20])
        self.image.fill((0, 0, 255))

        self.rect = self.image.get_rect()
        self.rect.x = pos[0]
        self.rect.y = pos[1]

    def update(self, platforms=None):
        if platforms:
            if pygame.sprite.spritecollideany(self, platforms):
                self.rect = self.rect.move(0, 0)
            else:
                self.rect = self.rect.move(0, 1)

    def move(self, is_left):
        if is_left:
            self.rect = self.rect.move(-10, 0)
        else:
            self.rect = self.rect.move(10, 0)

