import sys

import pygame

from extensions import generate_level, load_level, check_map_exist
from screens import start_screen, loading_screen

from constansts import *


def terminate():
    pygame.quit()
    sys.exit()


if __name__ == '__main__':
    # начальные настройки
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    clock = pygame.time.Clock()

    # группы спрайтов
    all_sprites = pygame.sprite.Group()
    tiles_group = pygame.sprite.Group()
    walls_group = pygame.sprite.Group()
    player_group = pygame.sprite.Group()

    player = None

    loading_screen(screen)
    pygame.display.flip()

    map_file = input()
    if check_map_exist(map_file) != '':
        print("Приступайте и игре!")

    # основной игровой цикл
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif (event.type == pygame.MOUSEBUTTONDOWN or event.type == pygame.KEYDOWN) and not player:
                player, level_x, level_y = generate_level(load_level(map_file), all_sprites, tiles_group,
                                                          walls_group,
                                                          player_group)
            elif event.type == pygame.KEYDOWN:
                player.move(event, walls=walls_group)

        if not player:
            start_screen(screen)
        else:
            screen.fill((0, 0, 0))

        # отрисывываем все спрайты
        tiles_group.draw(screen)
        player_group.draw(screen)

        # для отрисовки
        pygame.display.flip()
        clock.tick(FPS)
