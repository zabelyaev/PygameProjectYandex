from pygame.sprite import Sprite

from constansts import TILE_WIDTH, TILE_HEIGHT


class Tile(Sprite):
    def __init__(self, tile_image, pos, *groups):
        super().__init__(*groups)

        self.image = tile_image
        self.rect = self.image.get_rect()

        self.rect = self.rect.move(TILE_WIDTH * pos[0], TILE_HEIGHT * pos[1])
