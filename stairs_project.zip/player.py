import pygame
from pygame.sprite import Sprite


class Player(Sprite):
    def __init__(self, pos, *sprite_groups):
        super().__init__(*sprite_groups)

        self.image = pygame.Surface([20, 20])
        self.image.fill((0, 0, 255))

        self.rect = self.image.get_rect()
        self.rect.x = pos[0]
        self.rect.y = pos[1]

        self.can_move_up = False

    def update(self, platforms=None, stairs=None):
        if not self.can_move_up:
            if platforms:
                if pygame.sprite.spritecollideany(self, platforms):
                    self.rect = self.rect.move(0, 0)
                else:
                    self.rect = self.rect.move(0, 1)
            else:
                self.rect = self.rect.move(0, 1)
        if stairs:
            if pygame.sprite.spritecollideany(self, stairs):
                self.can_move_up = True
            else:
                self.can_move_up = False

    def move(self, is_left=None, is_up=None):
        if is_left is not None:
            if is_left:
                self.rect = self.rect.move(-10, 0)
            else:
                self.rect = self.rect.move(10, 0)
        if is_up is not None and self.can_move_up:
            if is_up:
                self.rect = self.rect.move(0, -10)
            else:
                self.rect = self.rect.move(0, 10)
