import pygame
from pygame import Surface
from pygame.sprite import Sprite

from platform import Platform, Stairs
from player import Player

if __name__ == '__main__':
    # начальные настройки
    pygame.init()
    size = width, height = 500, 500
    screen = pygame.display.set_mode((width, height))
    clock = pygame.time.Clock()
    FPS = 50

    # задаем Sprite группы
    player_group = pygame.sprite.Group()
    all_platforms = pygame.sprite.Group()
    all_stairs = pygame.sprite.Group()

    player = None

    running = True
    # основной игровой цикл
    while running:
        for event in pygame.event.get():
            keys_pressed = pygame.key.get_pressed()  # зажатые клавиши
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                # перемещения игрока
                if player:
                    if event.key == pygame.K_LEFT:
                        player.move(is_left=True)
                    elif event.key == pygame.K_RIGHT:
                        player.move(is_left=False)
                    elif event.key == pygame.K_UP:
                        player.move(is_up=True)
                    elif event.key == pygame.K_DOWN:
                        player.move(is_up=False)
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 3:
                    # удаляем игрока и спавним заново
                    player_group.empty()
                    player = Player(event.pos, player_group)
                elif event.button == 1:
                    # если зажат один из CTRL
                    if keys_pressed[pygame.K_LCTRL] or keys_pressed[pygame.K_RCTRL]:
                        # спавним лестницу
                        Stairs(event.pos, all_stairs)
                    else:
                        # спавним платформу
                        Platform(event.pos, all_platforms)

        # отрисовывем экран
        screen.fill((0, 0, 0))

        # отрисовываем игрока
        player_group.draw(screen)
        player_group.update(all_platforms, all_stairs)

        # отрисовываем платформы
        all_platforms.draw(screen)

        # отрисовываем лесенки
        all_stairs.draw(screen)

        # для отрисовки
        pygame.display.flip()
        clock.tick(FPS)
