import pygame
from pygame.sprite import Sprite


class BasePlatform(Sprite):
    def __init__(self, pos, *sprite_groups):
        super().__init__(*sprite_groups)
        self.pos = pos

    def init_platform(self, color, size):
        self.image = pygame.Surface(size)
        self.image.fill(color)

        self.rect = self.image.get_rect()
        self.rect.x = self.pos[0]
        self.rect.y = self.pos[1]


class Platform(BasePlatform):
    def __init__(self, pos, *sprite_groups):
        super().__init__(pos, *sprite_groups)

        self.color = (125, 125, 125)
        self.size = (100, 10)

        self.init_platform(self.color, self.size)


class Stairs(BasePlatform):
    def __init__(self, pos, *sprite_groups):
        super().__init__(pos, *sprite_groups)
        self.color = (255, 0, 0)
        self.size = (10, 100)

        self.init_platform(self.color, self.size)