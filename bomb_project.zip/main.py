import pygame
from bomb import Bomb

if __name__ == '__main__':
    pygame.init()
    size = width, height = 500, 500
    screen = pygame.display.set_mode((width, height))

    bomb_sprites = pygame.sprite.Group()

    for i in range(30):
        Bomb(screen, bomb_sprites)

    running = True

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                bomb_sprites.update(event)

        # отрисовывем экран и бомбы
        screen.fill((0, 0, 0))
        bomb_sprites.draw(screen)
        bomb_sprites.update()

        pygame.display.flip()
