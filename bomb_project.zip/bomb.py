import random

from pygame import MOUSEBUTTONDOWN
from pygame.sprite import Sprite
from extensions import load_image


class Bomb(Sprite):
    def __init__(self, screen, *group):
        super().__init__(*group)

        self.image_bomb = load_image('bomb.png')
        self.image_boom = load_image('boom.png')

        self.image = self.image_bomb
        self.rect = self.image.get_rect()

        # 5 - небольшой отступ от края
        self.rect.x = random.randrange(5, screen.get_width() - self.rect.width - 5)
        self.rect.y = random.randrange(5, screen.get_height() - self.rect.height - 5)

    def update(self, *args):
        if args and args[0].type == MOUSEBUTTONDOWN and self.rect.collidepoint(args[0].pos):
            self.image = self.image_boom
